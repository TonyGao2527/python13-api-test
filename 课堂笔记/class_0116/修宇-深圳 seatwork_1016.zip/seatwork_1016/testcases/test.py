# @Time   : 2019-04-03 21:59:06
# @Author : lemon_xiuyu
# @Email  : 5942527@qq.com
# @File   : test.py

from common.do_excel import DoExcel
do_excel = DoExcel("..//datas//cases.xlsx")
# do_excel = DoExcel("..//datas//cases.xlsx")